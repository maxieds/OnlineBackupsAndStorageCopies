#### ecc-configure.py : configuration and session exchange accounting for an 
####                    ECC exchange between Alice and Bob (and Eve)
#### Author: Maxie D. Schmidt (2018.04.05)

from sage.all import *
import collections
import random

ECCParams = collections.namedtuple('ECCParams', 'cfA cfB bbits E gfq')

def getECCParams(cfA, cfB, bbits): 
     gfq = next_prime(2 ** (2 * bbits)) # appropriate size of the 
                                        # finite field for b-bit key sizes
     E = EllipticCurve(GF(gfq), [cfA, cfB])
     return ECCParams(cfA = cfA, cfB = cfB, bbits = bbits, E = E, gfq = gfq)
## 

def MMP(ecc_params):
     return ceil(ecc_params.gfq / 256.0)
## 

ECCCrypto = collections.namedtuple('ECCCrypto', 'BobP Bobs BobB E q')

def getRandomizedECCCryptoSetup(ecc_params):
     s = ZZ.random_element(1, ecc_params.gfq - 1)
     P = ecc_params.E.random_point()
     B = s * P
     return ECCCrypto(BobP = P, Bobs = s, BobB = B, E = ecc_params.E, q = ecc_params.gfq)
##

def prettyPrintConfig(ecc_params, ecc_crypto = None): 
     print " ========================================================================= \n"
     print " BASE ECC PARAMETERS:"
     print "  >> ELLIPTIC CURVE EQN:  y^2 = x^3 + %d * x + %d" % \
           (ecc_params.cfA, ecc_params.cfB)
     print "  >> KEY BIT SIZE:        %d" % ecc_params.bbits
     print "  >> WORKING FFIELD SIZE: %d [2^{2 * %d}]" % \
           (ecc_params.gfq, ecc_params.bbits)
     print "  >> SIZE OF E (or |E|):  %d\n" % ecc_params.E.cardinality()
     if ecc_crypto != None:
          print " CHOICES OF SEMI-RANDOMIZED ECC-BASED PKC SETTINGS:"
          print "  >> BOB'S PUBLIC P:  ", ecc_crypto.BobP
          print "  >> BOB'S PRIVATE s: ", ecc_crypto.Bobs
          print "  >> BOB'S PUBLIC B:  ", ecc_crypto.BobB
          print ""
     ## 
     print " ========================================================================= \n"
## 

