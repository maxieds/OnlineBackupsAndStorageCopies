#### ecc-exchange.py : Implements the protocol and demo algorithms in our 
####                   mocked up ECC PKC exchange between Alice and Bob (Eve)
#### Author: Maxie D. Schmidt (2018.04.05)

from sage.all import *
from ecc_configure import *
import time

def convertString2Ascii(s): 
     return [ord(ch) for ch in s]
## 

def convertAsciiArray2String(aa): 
     return "".join(chr(ac) for ac in aa)
##


def encodeAsciiCode(ascii_code, M, ecc_params): 
     sfunc = lambda xj: (xj ** 3) + ecc_params.cfA * xj + ecc_params.cfB
     for j in range(1, M): 
          xj = M * ascii_code + j
          sj = sfunc(xj)
          if jacobi_symbol(sj, ecc_params.gfq) == 1:
               sjsqrt = Integer(ecc_params.E.base_field()(sj).nth_root(2))
               return (xj, sjsqrt)
          ##
     ##
     print "ERROR: UNABLE TO ENCODE ASCII CODE #%d (\'%c\') !!!!!" % \
           (ascii_code, chr(ascii_code))
     return None
## 

def encodeMessage(msg, M, ecc_params): 
     ascii_codes = convertString2Ascii(msg)
     return map(lambda ac: encodeAsciiCode(ac, M, ecc_params), ascii_codes)
## 

def decodeToAsciiCode(xm, M, ecc_params):
     return floor(xm / M)
##

def Alice(msg, ecc_params, ecc_crypto): 
     start_time = time.time()
     encoded_msg = encodeMessage(msg, MMP(ecc_params), ecc_params)
     encrypted_msg = []
     for (i, (xi, yi)) in enumerate(encoded_msg): 
          Mi = ecc_params.E([xi, yi])
          k = ZZ.random_element(1, ecc_params.gfq - 1)
          (M1, M2) = (k * ecc_crypto.BobP, Mi + k * ecc_crypto.BobB)
          encrypted_msg += [(M1, M2)]
     ##
     return encrypted_msg, time.time() - start_time
## 

def Bob(cyphertext, ecc_params, ecc_crypto): 
     start_time = time.time()
     ascii_codes = []
     for (M1, M2) in cyphertext: 
          M_msg = M2 - ecc_crypto.Bobs * M1
          ac = decodeToAsciiCode(Integer(M_msg[0]), MMP(ecc_params), ecc_params) 
          ascii_codes += [ac]
     ## 
     return "".join(chr(ac) for ac in ascii_codes), time.time() - start_time
## 

def Eve(cyphertext, ecc_params, ecc_crypto): 
     start_time = time.time()
     P, Q = ecc_crypto.BobP, ecc_crypto.BobB
     m = ceil(sqrt(ecc_params.gfq))
     mP = m * P
     iP_array = []
     s = None
     for i in range(0, m): 
          iP_array += [i * P]
     ##
     for j in range(0, m):
         Dj = Q - j * m * P
         iidx = -1
         try:
              iidx = iP_array.index(Dj)
         except ValueError:
              continue
         ##
         s = i + j * m % ecc_params.gfq
         break
     ##
     ascii_codes = []
     for (M1, M2) in cyphertext: 
          M_msg = M2 - s * M1
          ac = decodeToAsciiCode(Integer(M_msg[0]), MMP(ecc_params), ecc_params) 
          ascii_codes += [ac]
     ## 
     cleartext = "".join(chr(ac) for ac in ascii_codes)
     return cleartext, time.time() - start_time
##

def exchangeMessage(msg, ecc_params, ecc_crypto, with_eve = false): 
     alice_ctext, alice_time = Alice(msg, ecc_params, ecc_crypto)
     print "ALICE ENCODES: \"%s\" (%g sec)" % (msg, alice_time)
     bob_decode, bob_time = Bob(alice_ctext, ecc_params, ecc_crypto)
     print "BOB DECRYPTS:  \"%s\" (%g sec)" % (bob_decode, bob_time)
     if with_eve:
          eve_bfdecode, eve_time = Eve(alice_ctext, ecc_params, ecc_crypto)
          print "EVE FINDS OUT: \"%s\" (%g sec)" % (msg, eve_time)
     ## 
     print ""
## 


